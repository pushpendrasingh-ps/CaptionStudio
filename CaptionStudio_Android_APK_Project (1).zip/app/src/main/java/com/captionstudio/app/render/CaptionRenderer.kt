package com.captionstudio.app.render

import android.graphics.*
import com.captionstudio.app.model.CaptionItem
import com.captionstudio.app.model.CaptionStyle
import com.captionstudio.app.model.FontResolver
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class CaptionRenderer {

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun buildStaticBackgroundBitmap(
        width: Int,
        height: Int,
        sourceBitmap: Bitmap?,
        style: CaptionStyle
    ): Bitmap {
        val out = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        drawBackground(canvas, width, height, sourceBitmap, style)
        return out
    }

    fun drawBackground(
        canvas: Canvas,
        width: Int,
        height: Int,
        sourceBitmap: Bitmap?,
        style: CaptionStyle
    ) {
        if (sourceBitmap != null && !sourceBitmap.isRecycled) {
            canvas.drawColor(Color.parseColor("#05070B"))
            val imgRatio = sourceBitmap.width.toFloat() / sourceBitmap.height.toFloat()
            val canRatio = width.toFloat() / height.toFloat()

            val drawW: Float
            val drawH: Float
            if (style.coverFit) {
                if (imgRatio > canRatio) {
                    drawH = height.toFloat()
                    drawW = drawH * imgRatio
                } else {
                    drawW = width.toFloat()
                    drawH = drawW / imgRatio
                }
            } else {
                if (imgRatio > canRatio) {
                    drawW = width.toFloat()
                    drawH = drawW / imgRatio
                } else {
                    drawH = height.toFloat()
                    drawW = drawH * imgRatio
                }
            }
            val left = (width - drawW) / 2f
            val top = (height - drawH) / 2f
            val dst = RectF(left, top, left + drawW, top + drawH)
            bgPaint.isFilterBitmap = true
            canvas.drawBitmap(sourceBitmap, null, dst, bgPaint)
        } else {
            val shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(
                    Color.parseColor("#0F172A"),
                    Color.parseColor("#1E1B4B"),
                    Color.parseColor("#090D16")
                ),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
            bgPaint.shader = shader
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
            bgPaint.shader = null
        }

        if (style.dimAlpha > 0.01f) {
            val aTop = (style.dimAlpha * 0.45f * 255).toInt().coerceIn(0, 255)
            val aBot = (min(0.9f, style.dimAlpha * 1.15f) * 255).toInt().coerceIn(0, 255)
            val vig = LinearGradient(
                0f, 0f, 0f, height.toFloat(),
                intArrayOf(
                    Color.argb(aTop, 0, 0, 0),
                    Color.argb(aTop, 0, 0, 0),
                    Color.argb(aBot, 0, 0, 0)
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            bgPaint.shader = vig
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
            bgPaint.shader = null
        }
    }

    fun renderFrame(
        canvas: Canvas,
        width: Int,
        height: Int,
        timeSec: Double,
        captions: List<CaptionItem>,
        style: CaptionStyle,
        cachedBg: Bitmap?,
        sourceBitmap: Bitmap?
    ) {
        if (cachedBg != null && !cachedBg.isRecycled) {
            canvas.drawBitmap(cachedBg, 0f, 0f, null)
        } else {
            drawBackground(canvas, width, height, sourceBitmap, style)
        }

        val activeCap = captions.firstOrNull { timeSec >= it.startSec && timeSec <= it.endSec } ?: return
        val rawText = if (style.uppercase) activeCap.text.uppercase() else activeCap.text
        val words = rawText.trim().split(Regex("\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return

        val capDur = max(0.1, activeCap.endSec - activeCap.startSec)
        val progress = ((timeSec - activeCap.startSec) / capDur).coerceIn(0.0, 0.9999)
        val activeWordIdx = min(words.size - 1, floor(progress * words.size).toInt())

        val scaleFactor = min(width, height) / 720f
        val fontSizePx = style.fontSize * scaleFactor
        val tf = FontResolver.resolve(style)

        fillPaint.typeface = tf
        fillPaint.textSize = fontSizePx
        fillPaint.style = Paint.Style.FILL
        fillPaint.setShadowLayer(fontSizePx * 0.14f, 0f, fontSizePx * 0.06f, Color.argb(190, 0, 0, 0))

        strokePaint.typeface = tf
        strokePaint.textSize = fontSizePx
        strokePaint.style = Paint.Style.STROKE
        strokePaint.strokeJoin = Paint.Join.ROUND
        strokePaint.strokeWidth = style.strokeWidth * scaleFactor * 1.4f
        strokePaint.color = Color.argb(235, 0, 0, 0)

        val maxTextWidth = width * (style.maxWidthPct / 100f)
        val indexedWords = words.mapIndexed { idx, w -> idx to w }
        val lines = mutableListOf<List<Pair<Int, String>>>()
        var currentLine = mutableListOf<Pair<Int, String>>()

        for (pair in indexedWords) {
            val testStr = (currentLine + pair).joinToString(" ") { it.second }
            if (fillPaint.measureText(testStr) > maxTextWidth && currentLine.isNotEmpty()) {
                lines.add(currentLine)
                currentLine = mutableListOf(pair)
            } else {
                currentLine.add(pair)
            }
        }
        if (currentLine.isNotEmpty()) lines.add(currentLine)

        val lineWidths = lines.map { line ->
            fillPaint.measureText(line.joinToString(" ") { it.second })
        }
        val widest = lineWidths.maxOrNull() ?: 0f
        val lineHeight = fontSizePx * 1.28f
        val totalTextH = lines.size * lineHeight

        val padX = fontSizePx * 0.55f
        val padY = fontSizePx * 0.32f
        val boxW = widest + padX * 2f
        val boxH = totalTextH + padY * 2f

        val centerX = width * (style.posX / 100f)
        val centerY = height * (style.posY / 100f)
        val boxX = (centerX - boxW / 2f).coerceIn(20f, max(20f, width - boxW - 20f))
        val boxY = (centerY - boxH / 2f).coerceIn(20f, max(20f, height - boxH - 20f))

        if (style.bgOpacity > 0.01f) {
            boxPaint.color = Color.argb(
                (style.bgOpacity * 255).toInt().coerceIn(0, 255),
                Color.red(style.bgColor),
                Color.green(style.bgColor),
                Color.blue(style.bgColor)
            )
            val corner = fontSizePx * 0.32f
            canvas.drawRoundRect(RectF(boxX, boxY, boxX + boxW, boxY + boxH), corner, corner, boxPaint)
        }

        val spaceW = fillPaint.measureText(" ")
        val fm = fillPaint.fontMetrics
        val baselineOffset = -(fm.ascent + fm.descent) / 2f

        lines.forEachIndexed { li, line ->
            val lw = lineWidths[li]
            var cursorX = boxX + (boxW - lw) / 2f
            val lineCenterY = boxY + padY + li * lineHeight + lineHeight / 2f
            val baselineY = lineCenterY + baselineOffset

            line.forEachIndexed { wi, (wordIdx, wordStr) ->
                val isHighlighted = style.karaoke && wordIdx == activeWordIdx
                fillPaint.color = if (isHighlighted) style.highlightColor else style.textColor

                if (style.strokeWidth > 0.1f) {
                    canvas.drawText(wordStr, cursorX, baselineY, strokePaint)
                }
                canvas.drawText(wordStr, cursorX, baselineY, fillPaint)
                cursorX += fillPaint.measureText(wordStr) + if (wi < line.lastIndex) spaceW else 0f
            }
        }
    }
}
