package com.captionstudio.app.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.*
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.captionstudio.app.model.AspectRatioOption
import com.captionstudio.app.model.CaptionItem
import com.captionstudio.app.model.CaptionStyle
import com.captionstudio.app.render.CaptionRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.min

data class ExportProgress(
    val percent: Int,
    val statusText: String
)

class FastMp4Exporter(private val context: Context) {

    private val renderer = CaptionRenderer()

    private fun buildSmartTimeline(
        durationSec: Double,
        captions: List<CaptionItem>,
        karaoke: Boolean
    ): List<Pair<Double, Double>> {
        val pts = sortedSetOf(0.0, durationSec)
        for (c in captions) {
            val s = c.startSec.coerceIn(0.0, durationSec)
            val e = c.endSec.coerceIn(s, durationSec)
            if (e <= s) continue
            pts.add(s)
            pts.add(e)
            if (karaoke) {
                val words = c.text.trim().split(Regex("\s+")).filter { it.isNotEmpty() }
                if (words.size > 1) {
                    val d = e - s
                    for (wi in 1 until words.size) {
                        pts.add(s + (wi.toDouble() / words.size) * d)
                    }
                }
            }
        }

        val raw = pts.toList()
        val merged = mutableListOf(raw.first())
        for (i in 1 until raw.size) {
            if (raw[i] - merged.last() >= 0.03) merged.add(raw[i])
        }
        if (merged.last() < durationSec - 0.02) merged.add(durationSec)

        // Subdivide spans > 2.0s so seeking stays instant on YouTube/CapCut
        val segs = mutableListOf<Pair<Double, Double>>()
        val maxSpan = 2.0
        for (i in 0 until merged.lastIndex) {
            var cur = merged[i]
            val end = merged[i + 1]
            while (end - cur > maxSpan + 0.05) {
                segs.add(cur to (cur + maxSpan))
                cur += maxSpan
            }
            if (end - cur >= 0.02) segs.add(cur to end)
        }
        return segs
    }

    suspend fun export1080pMp4(
        imageBitmap: Bitmap?,
        audioUri: Uri?,
        durationSec: Double,
        captions: List<CaptionItem>,
        style: CaptionStyle,
        ratio: AspectRatioOption,
        onProgress: (ExportProgress) -> Unit
    ): Uri = withContext(Dispatchers.IO) {
        val width = ratio.width
        val height = ratio.height
        val tempOut = File(context.cacheDir, "captionstudio_export_${System.currentTimeMillis()}.mp4")
        val cachedBg = renderer.buildStaticBackgroundBitmap(width, height, imageBitmap, style)

        val videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 6_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, 24)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }

        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        encoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inputSurface = encoder.createInputSurface()
        encoder.start()

        val muxer = MediaMuxer(tempOut.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var videoTrackIndex = -1
        var audioTrackIndex = -1
        var muxerStarted = false

        // Prepare audio: direct passthrough for M4A/AAC, automatic MP3/WAV/OGG -> AAC conversion
        var audioExtractor: MediaExtractor? = null
        var sourceAudioTrack = -1
        var sourceAudioFormat: MediaFormat? = null
        var tempAacFile: File? = null

        if (audioUri != null) {
            try {
                val probe = MediaExtractor()
                probe.setDataSource(context, audioUri, null)
                var foundTrack = -1
                var foundFmt: MediaFormat? = null
                var foundMime = ""
                for (i in 0 until probe.trackCount) {
                    val fmt = probe.getTrackFormat(i)
                    val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("audio/")) {
                        foundTrack = i
                        foundFmt = fmt
                        foundMime = mime
                        break
                    }
                }
                if (foundTrack >= 0 && foundFmt != null) {
                    if (foundMime.startsWith("audio/mp4a") || foundMime.startsWith("audio/aac")) {
                        probe.selectTrack(foundTrack)
                        audioExtractor = probe
                        sourceAudioTrack = foundTrack
                        sourceAudioFormat = foundFmt
                    } else {
                        // Automatically convert MP3 / WAV / OGG / FLAC to AAC (.m4a)
                        probe.release()
                        onProgress(ExportProgress(2, "Converting MP3/audio to AAC..."))
                        val converted = transcodeAudioToAac(audioUri, durationSec) { pct ->
                            val scaled = (pct * 0.25f).toInt().coerceIn(2, 25)
                            onProgress(ExportProgress(scaled, "Converting audio to AAC ($pct%)..."))
                        }
                        if (converted != null && converted.exists()) {
                            tempAacFile = converted
                            val aacEx = MediaExtractor()
                            aacEx.setDataSource(converted.absolutePath)
                            for (i in 0 until aacEx.trackCount) {
                                val fmt = aacEx.getTrackFormat(i)
                                if ((fmt.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                                    aacEx.selectTrack(i)
                                    audioExtractor = aacEx
                                    sourceAudioTrack = i
                                    sourceAudioFormat = fmt
                                    break
                                }
                            }
                            if (audioExtractor == null) aacEx.release()
                        }
                    }
                } else {
                    probe.release()
                }
            } catch (_: Exception) {
            }
        }

        val bufferInfo = MediaCodec.BufferInfo()
        val segments = buildSmartTimeline(max(1.0, durationSec), captions, style.karaoke)
        val totalSegs = max(1, segments.size)
        val pendingPtsUs = ArrayDeque<Long>()
        var lastWrittenPtsUs = -1L

        fun drainEncoder(endOfStream: Boolean) {
            if (endOfStream) encoder.signalEndOfInputStream()
            while (true) {
                val status = encoder.dequeueOutputBuffer(bufferInfo, 10_000)
                when {
                    status == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!endOfStream) break
                    }
                    status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        videoTrackIndex = muxer.addTrack(encoder.outputFormat)
                        val aFmt = sourceAudioFormat
                        if (aFmt != null) {
                            audioTrackIndex = muxer.addTrack(aFmt)
                        }
                        muxer.start()
                        muxerStarted = true
                    }
                    status >= 0 -> {
                        val encodedData = encoder.getOutputBuffer(status)
                        if (encodedData != null && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && bufferInfo.size > 0 && muxerStarted) {
                            val nextPts = if (pendingPtsUs.isNotEmpty()) pendingPtsUs.removeFirst() else (lastWrittenPtsUs + 41_667L)
                            bufferInfo.presentationTimeUs = max(lastWrittenPtsUs + 1_000L, nextPts)
                            lastWrittenPtsUs = bufferInfo.presentationTimeUs
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                        }
                        encoder.releaseOutputBuffer(status, false)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                    }
                }
            }
        }

        try {
            val startWall = System.currentTimeMillis()
            for ((idx, seg) in segments.withIndex()) {
                coroutineContext.ensureActive()
                val sampleT = seg.first + min(0.01, (seg.second - seg.first) * 0.25)
                pendingPtsUs.addLast((seg.first * 1_000_000.0).toLong())

                val canvas = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    inputSurface.lockHardwareCanvas()
                } else {
                    inputSurface.lockCanvas(null)
                }
                renderer.renderFrame(canvas, width, height, sampleT, captions, style, cachedBg, imageBitmap)
                inputSurface.unlockCanvasAndPost(canvas)

                drainEncoder(false)

                if (idx % 4 == 0 || idx == segments.lastIndex) {
                    val pct = (((idx + 1).toFloat() / totalSegs) * 90f).toInt().coerceIn(1, 90)
                    val elapsed = max(0.1, (System.currentTimeMillis() - startWall) / 1000.0)
                    val speedX = String.format("%.1f", seg.second / elapsed)
                    onProgress(ExportProgress(pct, "Hardware 1080p (${speedX}x) • Frame ${idx + 1}/$totalSegs"))
                }
            }
            drainEncoder(true)

            // Fast-mux AAC/M4A audio if available
            val aEx = audioExtractor
            if (aEx != null && audioTrackIndex >= 0 && muxerStarted) {
                onProgress(ExportProgress(94, "Muxing audio track..."))
                val audioBuf = ByteBuffer.allocate(256 * 1024)
                val aInfo = MediaCodec.BufferInfo()
                while (true) {
                    coroutineContext.ensureActive()
                    val sampleSize = aEx.readSampleData(audioBuf, 0)
                    if (sampleSize < 0) break
                    aInfo.offset = 0
                    aInfo.size = sampleSize
                    aInfo.presentationTimeUs = aEx.sampleTime
                    aInfo.flags = aEx.sampleFlags
                    muxer.writeSampleData(audioTrackIndex, audioBuf, aInfo)
                    aEx.advance()
                }
            }
        } finally {
            try { encoder.stop() } catch (_: Exception) {}
            try { encoder.release() } catch (_: Exception) {}
            try { inputSurface.release() } catch (_: Exception) {}
            try { audioExtractor?.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer.stop() } catch (_: Exception) {}
            try { muxer.release() } catch (_: Exception) {}
            try { tempAacFile?.delete() } catch (_: Exception) {}
            cachedBg.recycle()
        }

        onProgress(ExportProgress(98, "Saving to Gallery (Movies/CaptionStudio)..."))
        val savedUri = saveToGallery(tempOut)
        tempOut.delete()
        onProgress(ExportProgress(100, "Saved 1080p MP4 to Movies/CaptionStudio!"))
        savedUri
    }

    private suspend fun transcodeAudioToAac(
        audioUri: Uri,
        durationSec: Double,
        onPct: (Int) -> Unit
    ): File? {
        val outFile = File(context.cacheDir, "captionstudio_aac_${System.currentTimeMillis()}.m4a")
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false

        try {
            extractor.setDataSource(context, audioUri, null)
            var trackIdx = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                if ((fmt.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                    trackIdx = i
                    inputFormat = fmt
                    break
                }
            }
            if (trackIdx < 0 || inputFormat == null) return null
            extractor.selectTrack(trackIdx)

            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: return null
            val sampleRate = if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            } else 44100
            val channelCount = if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceIn(1, 2)
            } else 2

            val dec = MediaCodec.createDecoderByType(mime)
            decoder = dec
            dec.configure(inputFormat, null, null, 0)
            dec.start()

            val aacFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channelCount).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            encoder = enc
            enc.configure(aacFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()

            val mx = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mx
            var audioTrackIndex = -1

            val decInfo = MediaCodec.BufferInfo()
            val encInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var decodeDone = false
            var encodeDone = false
            var lastReportedPct = -1
            val totalUs = max(1_000_000L, (durationSec * 1_000_000.0).toLong())

            while (!encodeDone) {
                coroutineContext.ensureActive()

                // 1. Feed compressed MP3/WAV packets into decoder
                if (!inputDone) {
                    val inIdx = dec.dequeueInputBuffer(5_000)
                    if (inIdx >= 0) {
                        val inBuf = dec.getInputBuffer(inIdx)!!
                        val sampleSize = extractor.readSampleData(inBuf, 0)
                        if (sampleSize < 0) {
                            dec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val pts = extractor.sampleTime
                            dec.queueInputBuffer(inIdx, 0, sampleSize, pts, 0)
                            extractor.advance()
                        }
                    }
                }

                // 2. Pull decoded PCM from decoder and feed into AAC encoder
                if (!decodeDone) {
                    val outIdx = dec.dequeueOutputBuffer(decInfo, 5_000)
                    if (outIdx >= 0) {
                        val pcmBuf = dec.getOutputBuffer(outIdx)!!
                        val isEos = (decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        if (decInfo.size > 0) {
                            pcmBuf.position(decInfo.offset)
                            pcmBuf.limit(decInfo.offset + decInfo.size)
                            var remaining = decInfo.size
                            var chunkPts = decInfo.presentationTimeUs
                            while (remaining > 0) {
                                coroutineContext.ensureActive()
                                val encInIdx = enc.dequeueInputBuffer(5_000)
                                if (encInIdx >= 0) {
                                    val encInBuf = enc.getInputBuffer(encInIdx)!!
                                    encInBuf.clear()
                                    val toCopy = min(remaining, encInBuf.remaining())
                                    val oldLimit = pcmBuf.limit()
                                    pcmBuf.limit(pcmBuf.position() + toCopy)
                                    encInBuf.put(pcmBuf)
                                    pcmBuf.limit(oldLimit)
                                    enc.queueInputBuffer(encInIdx, 0, toCopy, chunkPts, 0)
                                    remaining -= toCopy
                                    chunkPts += (toCopy.toLong() * 1_000_000L) / (sampleRate.toLong() * channelCount * 2L)
                                } else {
                                    // Drain encoder output to prevent backpressure stall
                                    val eOut = enc.dequeueOutputBuffer(encInfo, 2_000)
                                    if (eOut == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                                        audioTrackIndex = mx.addTrack(enc.outputFormat)
                                        mx.start()
                                        muxerStarted = true
                                    } else if (eOut >= 0) {
                                        val aBuf = enc.getOutputBuffer(eOut)
                                        if (aBuf != null && (encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && encInfo.size > 0 && muxerStarted) {
                                            aBuf.position(encInfo.offset)
                                            aBuf.limit(encInfo.offset + encInfo.size)
                                            mx.writeSampleData(audioTrackIndex, aBuf, encInfo)
                                        }
                                        enc.releaseOutputBuffer(eOut, false)
                                    }
                                }
                            }
                            val pct = ((decInfo.presentationTimeUs * 100L) / totalUs).toInt().coerceIn(0, 99)
                            if (pct > lastReportedPct + 2) {
                                lastReportedPct = pct
                                onPct(pct)
                            }
                        }
                        dec.releaseOutputBuffer(outIdx, false)
                        if (isEos) {
                            decodeDone = true
                            val encInIdx = enc.dequeueInputBuffer(10_000)
                            if (encInIdx >= 0) {
                                enc.queueInputBuffer(encInIdx, 0, 0, decInfo.presentationTimeUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            }
                        }
                    }
                }

                // 3. Drain AAC encoder into temp .m4a muxer
                var drainMore = true
                while (drainMore) {
                    val encOutIdx = enc.dequeueOutputBuffer(encInfo, 5_000)
                    when {
                        encOutIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> drainMore = false
                        encOutIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            audioTrackIndex = mx.addTrack(enc.outputFormat)
                            mx.start()
                            muxerStarted = true
                        }
                        encOutIdx >= 0 -> {
                            val aacBuf = enc.getOutputBuffer(encOutIdx)
                            if (aacBuf != null && (encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && encInfo.size > 0 && muxerStarted) {
                                aacBuf.position(encInfo.offset)
                                aacBuf.limit(encInfo.offset + encInfo.size)
                                mx.writeSampleData(audioTrackIndex, aacBuf, encInfo)
                            }
                            enc.releaseOutputBuffer(encOutIdx, false)
                            if ((encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                encodeDone = true
                                drainMore = false
                            }
                        }
                    }
                }
            }
            onPct(100)
            return outFile
        } finally {
            try { extractor.release() } catch (_: Exception) {}
            try { decoder?.stop(); decoder?.release() } catch (_: Exception) {}
            try { encoder?.stop(); encoder?.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop(); muxer?.release() } catch (_: Exception) {}
        }
    }

    private fun saveToGallery(file: File): Uri {
        val fileName = "CaptionStudio_1080p_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/CaptionStudio")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create MediaStore entry")

        resolver.openOutputStream(uri)?.use { out ->
            FileInputStream(file).use { input -> input.copyTo(out) }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        }
        return uri
    }
}
