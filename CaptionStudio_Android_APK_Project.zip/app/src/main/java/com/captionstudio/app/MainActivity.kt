package com.captionstudio.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.captionstudio.app.export.ExportProgress
import com.captionstudio.app.export.FastMp4Exporter
import com.captionstudio.app.model.*
import com.captionstudio.app.render.CaptionRenderer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF6366F1),
                background = Color(0xFF0B0D12),
                surface = Color(0xFF111520)
            )) {
                CaptionStudioScreen()
            }
        }
    }
}

@Composable
fun CaptionStudioScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val renderer = remember { CaptionRenderer() }
    val exporter = remember { FastMp4Exporter(context) }

    var ratio by remember { mutableStateOf(AspectRatioOption.LANDSCAPE_16_9) }
    var imageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var imageLabel by remember { mutableStateOf("Tap to pick Image") }

    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var audioLabel by remember { mutableStateOf("Tap to pick Audio") }
    var durationSec by remember { mutableDoubleStateOf(15.0) }
    var currentTimeSec by remember { mutableDoubleStateOf(0.5) }
    var isPlaying by remember { mutableStateOf(false) }

    var srtLabel by remember { mutableStateOf("Demo Captions (3)") }
    var captions by remember {
        mutableStateOf(
            listOf(
                CaptionItem("1", 0.2, 5.0, "1. Image, Audio aur SRT file select karein"),
                CaptionItem("2", 5.1, 10.0, "Drag ya Arrow icons se text kahin bhi move karein"),
                CaptionItem("3", 10.1, 15.0, "A- / A+ se size badlein aur 1080p MP4 export karein!")
            )
        )
    }

    var style by remember { mutableStateOf(StylePresets.youtubeBold) }
    var fontDropdownExpanded by remember { mutableStateOf(false) }
    var customFontName by remember { mutableStateOf<String?>(null) }

    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableStateOf(ExportProgress(0, "")) }

    val mediaPlayer = remember { MediaPlayer() }
    DisposableEffect(Unit) {
        onDispose {
            try { mediaPlayer.release() } catch (_: Exception) {}
        }
    }

    // Playback ticker
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            if (audioUri != null) {
                try {
                    currentTimeSec = mediaPlayer.currentPosition / 1000.0
                    if (!mediaPlayer.isPlaying) isPlaying = false
                } catch (_: Exception) {
                    isPlaying = false
                }
            } else {
                currentTimeSec += 0.05
                if (currentTimeSec >= durationSec) {
                    currentTimeSec = 0.0
                    isPlaying = false
                }
            }
            delay(40)
        }
    }

    // File Pickers
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    imageBitmap = BitmapFactory.decodeStream(stream)
                    imageLabel = "Image Loaded"
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Image error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                audioUri = uri
                val mmr = MediaMetadataRetriever()
                mmr.setDataSource(context, uri)
                val durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 15000L
                mmr.release()
                durationSec = durMs / 1000.0
                currentTimeSec = 0.0
                mediaPlayer.reset()
                mediaPlayer.setDataSource(context, uri)
                mediaPlayer.prepare()
                audioLabel = "Audio (${SrtParser.formatTime(durationSec)})"
            } catch (e: Exception) {
                Toast.makeText(context, "Audio error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val srtPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val txt = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
                val parsed = SrtParser.parse(txt)
                if (parsed.isNotEmpty()) {
                    captions = parsed
                    srtLabel = "${parsed.size} captions loaded"
                    currentTimeSec = parsed.first().startSec + 0.05
                    Toast.makeText(context, "Loaded ${parsed.size} captions!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "No valid SRT timestamps found", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "SRT error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val outFile = File(context.cacheDir, "custom_font_${System.currentTimeMillis()}.ttf")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(outFile).use { output -> input.copyTo(output) }
                }
                customFontName = "Custom Font"
                style = style.copy(fontName = "Custom Font", customFontPath = outFile.absolutePath)
                Toast.makeText(context, "Custom font applied!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Font error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        containerColor = Color(0xFF0B0D12),
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0E1118))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("CaptionStudio 1080p", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AspectRatioOption.entries.forEach { opt ->
                        val active = ratio == opt
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) Color(0xFF4F46E5) else Color(0xFF1E293B))
                                .clickable { ratio = opt }
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                        ) {
                            Text(opt.label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Button(
                    onClick = {
                        if (!isExporting) {
                            isPlaying = false
                            try { if (mediaPlayer.isPlaying) mediaPlayer.pause() } catch (_: Exception) {}
                            isExporting = true
                            scope.launch {
                                try {
                                    exporter.export1080pMp4(
                                        imageBitmap = imageBitmap,
                                        audioUri = audioUri,
                                        durationSec = durationSec,
                                        captions = captions,
                                        style = style,
                                        ratio = ratio
                                    ) { prog -> exportProgress = prog }
                                    Toast.makeText(context, "Saved 1080p MP4 to Movies/CaptionStudio!", Toast.LENGTH_LONG).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
                                } finally {
                                    isExporting = false
                                }
                            }
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Export", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. Upload Row (Image / Audio / SRT)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                UploadChip(Modifier.weight(1f), "1. Image", imageLabel, Color(0xFF6366F1)) {
                    imagePicker.launch("image/*")
                }
                UploadChip(Modifier.weight(1f), "2. Audio", audioLabel, Color(0xFF10B981)) {
                    audioPicker.launch("audio/*")
                }
                UploadChip(Modifier.weight(1f), "3. SRT", srtLabel, Color(0xFF0EA5E9)) {
                    srtPicker.launch(arrayOf("*/*"))
                }
            }

            // 2. Interactive Preview Canvas (Touch Drag to Move Text!)
            val aspectFloat = ratio.width.toFloat() / ratio.height.toFloat()
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 280.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF05070B))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .aspectRatio(aspectFloat)
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                val dxPct = (dragAmount.x / size.width) * 100f
                                val dyPct = (dragAmount.y / size.height) * 100f
                                style = style.copy(
                                    posX = (style.posX + dxPct).coerceIn(8f, 92f),
                                    posY = (style.posY + dyPct).coerceIn(8f, 94f)
                                )
                            }
                        }
                ) {
                    renderer.renderFrame(
                        canvas = drawContext.canvas.nativeCanvas,
                        width = size.width.toInt().coerceAtLeast(1),
                        height = size.height.toInt().coerceAtLeast(1),
                        timeSec = currentTimeSec,
                        captions = captions,
                        style = style,
                        cachedBg = null,
                        sourceBitmap = imageBitmap
                    )
                }
            }

            // 3. Move Arrows & A- / A+ Icon Toolbar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF111520))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { style = style.copy(posX = (style.posX - 4f).coerceIn(8f, 92f)) }, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.KeyboardArrowLeft, "Left", tint = Color.White)
                    }
                    IconButton(onClick = { style = style.copy(posY = (style.posY - 4f).coerceIn(8f, 94f)) }, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.KeyboardArrowUp, "Up", tint = Color.White)
                    }
                    IconButton(onClick = { style = style.copy(posY = (style.posY + 4f).coerceIn(8f, 94f)) }, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.KeyboardArrowDown, "Down", tint = Color.White)
                    }
                    IconButton(onClick = { style = style.copy(posX = (style.posX + 4f).coerceIn(8f, 92f)) }, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.KeyboardArrowRight, "Right", tint = Color.White)
                    }
                    IconButton(onClick = { style = style.copy(posX = 50f, posY = 82f) }, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.CenterFocusStrong, "Center", tint = Color(0xFF818CF8))
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalButton(
                        onClick = { style = style.copy(fontSize = (style.fontSize - 4f).coerceIn(18f, 110f)) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(34.dp)
                    ) { Text("A-", fontWeight = FontWeight.Bold, fontSize = 12.sp) }

                    Text("${style.fontSize.toInt()}px", color = Color(0xFF818CF8), fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    FilledTonalButton(
                        onClick = { style = style.copy(fontSize = (style.fontSize + 4f).coerceIn(18f, 110f)) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(34.dp)
                    ) { Text("A+", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                }
            }

            // 4. Play/Pause & Timeline Scrubber
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF111520))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    if (isPlaying) {
                        isPlaying = false
                        try { if (mediaPlayer.isPlaying) mediaPlayer.pause() } catch (_: Exception) {}
                    } else {
                        if (audioUri != null) {
                            try {
                                mediaPlayer.seekTo((currentTimeSec * 1000).toInt())
                                mediaPlayer.start()
                            } catch (_: Exception) {}
                        }
                        isPlaying = true
                    }
                }) {
                    Icon(
                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play/Pause",
                        tint = Color.White
                    )
                }
                Slider(
                    value = currentTimeSec.toFloat().coerceIn(0f, durationSec.toFloat().coerceAtLeast(1f)),
                    onValueChange = {
                        currentTimeSec = it.toDouble()
                        if (audioUri != null) {
                            try { mediaPlayer.seekTo((it * 1000).toInt()) } catch (_: Exception) {}
                        }
                    },
                    valueRange = 0f..durationSec.toFloat().coerceAtLeast(1f),
                    modifier = Modifier.weight(1f)
                )
                Text(
                    SrtParser.formatTime(currentTimeSec),
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp
                )
            }

            // 5. Font Picker + Custom Font Upload + Presets
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111520)), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Font & Style", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        OutlinedButton(
                            onClick = { fontPicker.launch(arrayOf("*/*")) },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Default.UploadFile, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Upload .TTF/.OTF", fontSize = 11.sp)
                        }
                    }

                    // Font Dropdown
                    Box {
                        OutlinedButton(
                            onClick = { fontDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Font: ${style.fontName}", modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, null)
                        }
                        DropdownMenu(expanded = fontDropdownExpanded, onDismissRequest = { fontDropdownExpanded = false }) {
                            val allFonts = if (customFontName != null) listOf(customFontName!!) + FontResolver.builtInFonts else FontResolver.builtInFonts
                            allFonts.forEach { fname ->
                                DropdownMenuItem(
                                    text = { Text(fname) },
                                    onClick = {
                                        style = style.copy(
                                            fontName = fname,
                                            customFontPath = if (fname == customFontName) style.customFontPath else null
                                        )
                                        fontDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Quick Presets
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            "YouTube" to StylePresets.youtubeBold,
                            "Shorts" to StylePresets.shortsPop,
                            "Karaoke" to StylePresets.karaokeGlow,
                            "Cinema" to StylePresets.cinematic
                        ).forEach { (label, preset) ->
                            FilledTonalButton(
                                onClick = { style = preset.copy(customFontPath = style.customFontPath) },
                                modifier = Modifier.weight(1f).height(34.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp)
                            ) {
                                Text(label, fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }

                    // Karaoke & Uppercase Toggles
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = style.karaoke, onCheckedChange = { style = style.copy(karaoke = it) })
                            Text("Word Karaoke", color = Color.White, fontSize = 12.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = style.uppercase, onCheckedChange = { style = style.copy(uppercase = it) })
                            Text("UPPERCASE", color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    // Export Progress Dialog
    if (isExporting) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Fast 1080p Hardware Export") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(exportProgress.statusText.ifBlank { "Starting hardware encoder..." }, fontSize = 13.sp)
                    LinearProgressIndicator(
                        progress = { exportProgress.percent / 100f },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("${exportProgress.percent}%", fontWeight = FontWeight.Bold, color = Color(0xFF818CF8))
                }
            },
            confirmButton = {}
        )
    }
}

@Composable
private fun UploadChip(
    modifier: Modifier,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF111520))
            .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(title, color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(subtitle, color = Color(0xFFCBD5E1), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
