package com.captionstudio.app.model

import android.graphics.Color
import android.graphics.Typeface

enum class AspectRatioOption(val label: String, val width: Int, val height: Int) {
    LANDSCAPE_16_9("16:9", 1920, 1080),
    PORTRAIT_9_16("9:16", 1080, 1920),
    SQUARE_1_1("1:1", 1080, 1080)
}

data class CaptionItem(
    val id: String,
    val startSec: Double,
    val endSec: Double,
    val text: String
)

data class CaptionStyle(
    val fontName: String = "Sans Bold",
    val customFontPath: String? = null,
    val fontSize: Float = 44f,
    val posX: Float = 50f,
    val posY: Float = 82f,
    val maxWidthPct: Float = 84f,
    val textColor: Int = Color.WHITE,
    val highlightColor: Int = Color.parseColor("#FACC15"),
    val bgColor: Int = Color.parseColor("#090B10"),
    val bgOpacity: Float = 0.72f,
    val strokeWidth: Float = 4f,
    val karaoke: Boolean = true,
    val uppercase: Boolean = false,
    val coverFit: Boolean = true,
    val dimAlpha: Float = 0.25f
)

object StylePresets {
    val youtubeBold = CaptionStyle(
        fontName = "Sans Bold", fontSize = 44f, posX = 50f, posY = 82f,
        textColor = Color.WHITE, highlightColor = Color.parseColor("#FACC15"),
        bgColor = Color.parseColor("#090B10"), bgOpacity = 0.72f, strokeWidth = 4f,
        karaoke = true, uppercase = false
    )
    val shortsPop = CaptionStyle(
        fontName = "Condensed Bold", fontSize = 58f, posX = 50f, posY = 56f,
        textColor = Color.WHITE, highlightColor = Color.parseColor("#FBBF24"),
        bgColor = Color.BLACK, bgOpacity = 0f, strokeWidth = 8f,
        karaoke = true, uppercase = true
    )
    val karaokeGlow = CaptionStyle(
        fontName = "Sans Bold", fontSize = 48f, posX = 50f, posY = 78f,
        textColor = Color.parseColor("#E2E8F0"), highlightColor = Color.parseColor("#34D399"),
        bgColor = Color.parseColor("#0F172A"), bgOpacity = 0.82f, strokeWidth = 3f,
        karaoke = true, uppercase = false
    )
    val cinematic = CaptionStyle(
        fontName = "Serif", fontSize = 34f, posX = 50f, posY = 86f,
        textColor = Color.WHITE, highlightColor = Color.WHITE,
        bgColor = Color.BLACK, bgOpacity = 0.45f, strokeWidth = 2f,
        karaoke = false, uppercase = false
    )
}

object FontResolver {
    val builtInFonts = listOf("Sans Bold", "Condensed Bold", "Serif", "Monospace")

    fun resolve(style: CaptionStyle): Typeface {
        val customPath = style.customFontPath
        if (!customPath.isNullOrBlank()) {
            try {
                return Typeface.createFromFile(customPath)
            } catch (_: Exception) {
            }
        }
        return when (style.fontName) {
            "Condensed Bold" -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
            "Serif" -> Typeface.create(Typeface.SERIF, Typeface.BOLD)
            "Monospace" -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            else -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
    }
}

object SrtParser {
    private val arrowRegex = Regex(
        "(\\d{1,2}:\\d{2}(?::\\d{2})?(?:[.,]\\d{1,3})?)\\s*(?:-->|->|-|–)\\s*(\\d{1,2}:\\d{2}(?::\\d{2})?(?:[.,]\\d{1,3})?)"
    )

    fun parse(rawText: String): List<CaptionItem> {
        val normalized = rawText.replace("\r\n", "\n").replace("\r", "\n").trim()
        if (normalized.isEmpty()) return emptyList()

        val result = mutableListOf<CaptionItem>()
        val blocks = normalized.split(Regex("\\n\\s*\\n"))
        var idx = 1

        for (block in blocks) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty()) continue
            val timeLineIdx = lines.indexOfFirst { arrowRegex.containsMatchIn(it) }
            if (timeLineIdx != -1) {
                val match = arrowRegex.find(lines[timeLineIdx]) ?: continue
                val start = parseTimestamp(match.groupValues[1])
                val end = parseTimestamp(match.groupValues[2])
                val text = lines.drop(timeLineIdx + 1)
                    .joinToString(" ")
                    .replace(Regex("<[^>]+>"), "")
                    .trim()
                if (text.isNotEmpty() && end > start) {
                    result.add(CaptionItem("c_${idx++}", start, end, text))
                }
            }
        }
        return result.sortedBy { it.startSec }
    }

    fun parseTimestamp(ts: String): Double {
        val clean = ts.trim().replace(',', '.')
        val parts = clean.split(":").mapNotNull { it.toDoubleOrNull() }
        return when (parts.size) {
            3 -> parts[0] * 3600.0 + parts[1] * 60.0 + parts[2]
            2 -> parts[0] * 60.0 + parts[1]
            1 -> parts[0]
            else -> 0.0
        }
    }

    fun formatTime(sec: Double): String {
        val s = sec.coerceAtLeast(0.0)
        val hrs = (s / 3600).toInt()
        val mins = ((s % 3600) / 60).toInt()
        val rem = s % 60
        return if (hrs > 0) {
            String.format("%02d:%02d:%04.1f", hrs, mins, rem)
        } else {
            String.format("%02d:%04.1f", mins, rem)
        }
    }
}
