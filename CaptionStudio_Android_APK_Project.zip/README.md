# CaptionStudio Android App (1080p Fast MP4 Exporter)

Mobile ke liye bana **100% Native Android App** (Kotlin + Jetpack Compose + Hardware `MediaCodec` H.264).

## Features
- **3-Step Workflow:** 1 Image + Unlimited-Length Audio (`.mp3`, `.m4a`, `.wav`, `.ogg` — automatic MP3-to-AAC conversion) + `.SRT` / `.VTT` file upload.
- **Touch Drag + Arrow Buttons:** Preview par ungli se drag karke ya `◀ ▲ ▼ ▶` / `Center` icon buttons se text ko kahin bhi move karein.
- **A- / A+ Size Controls:** Ek tap mein text bada ya chota karein.
- **Custom Font Upload:** Apna `.ttf` ya `.otf` font select karke turant apply karein.
- **Ultra-Fast 1080p `.MP4` Export:** Android ki built-in hardware GPU chip + Smart Event-Frame encoding use karta hai (sirf caption/word change par frames encode hote hain + har 2s keyframe). Direct phone ki **Gallery / Movies / CaptionStudio** mein save hota hai.

---

## Phone se bina Laptop ke `.APK` kaise banayein (Free, 3 Minutes)

1. Apne phone ke browser mein [GitHub.com](https://github.com) par login karein aur **New Repository** banayein (naam rakhein `CaptionStudio`, Public ya Private).
2. Is `.zip` file ko unzip karein (ya GitHub app / browser mein **"Upload files"** karke saari files upload kar dein — `.github/workflows/build-apk.yml` folder zaroor upload ho).
3. Repository ke **Actions** tab mein jayein → **"Build CaptionStudio APK"** workflow par click karein (agar apne aap start na ho to **"Run workflow"** dabayein).
4. ~2–3 minute mein green tick aate hi us run ko kholein aur niche **Artifacts** section se **`CaptionStudio-1080p-APK`** download karke unzip & install kar lein!

*(Agar aapke paas PC/Laptop hai to bas is folder ko Android Studio mein open karke **Build → Build APK(s)** click kar dein.)*
